void host_blur(unsigned char* inputImage, unsigned char* outputImage, int size);
