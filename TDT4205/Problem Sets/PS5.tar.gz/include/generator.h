#include <stdio.h>
#include <stdbool.h>
#include "tree.h"
extern bool peephole;
void generate ( FILE *stream, node_t * );
